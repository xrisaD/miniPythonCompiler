a = open(2,3)
b = None
c = type(b)
