def add(x,y):
    return x + y
k = 3
print add(2 , k)
