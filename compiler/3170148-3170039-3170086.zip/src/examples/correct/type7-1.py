def add(x):
    return x
def add(x,y,z=1):
    return x
