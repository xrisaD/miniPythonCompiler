d = 1
a = ( 5 + open( 2 , 3))
a = (open(2,3) + 2) ** 2
a = (None + 3)
a  = (type(d) + 1)
