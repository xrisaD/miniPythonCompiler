def add(x,y,z):
    return x
def add(x,y,z=1):
    return x
