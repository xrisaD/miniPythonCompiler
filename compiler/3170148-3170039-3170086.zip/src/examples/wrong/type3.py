def a(x,y,z=1):
    return x
a(1)
