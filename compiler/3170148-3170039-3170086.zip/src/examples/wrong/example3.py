print 3 + 5 -2 + 4 + "kalispera"
open( "12" , "22")
