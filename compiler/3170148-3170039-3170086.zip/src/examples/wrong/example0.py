# import torch.nn as nn
# import nn

def BERTSystemWrapper(model_name, params, dp):
    for i in params:
        print 1 , 1 ,1
    assert true
    while true:
        dp = 1
        if true:print 1
    model_name -= 1
    params[true] = 1
    train(1, 1, 1)
